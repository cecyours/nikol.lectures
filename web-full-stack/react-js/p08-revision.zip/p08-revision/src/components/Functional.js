import React, { useState } from 'react'

export default function Functional() {
    
    const [username,setUserName] = useState("Pappu")

    const handle = () =>{
        setUserName("Vishal")
    }
  return (
    <div>
        <button onClick={handle}>Click</button>
        <h1>clicked {username}</h1>
    </div>
  )
}
