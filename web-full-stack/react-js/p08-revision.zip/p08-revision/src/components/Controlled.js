import React, { Component, useState } from 'react'
import { Button } from 'react-bootstrap'

export default class Controlled extends Component {

    constructor(props) {
        super(props)
        
        this.state = {
            userName:"dummy",
            name:''
        }
    }

    handle = (event) => {

        this.setState({
            userName:this.state.userName=this.state.name
        })
    }

    handleChange = (e)=>{

        this.setState({
            name:this.state.name = e.target.value
        })
    }
    render() {
        return (
            <div>
                <h1>Welcome {this.state.userName} </h1>
                <input onChange={this.handleChange}></input>
                <button onClick={this.handle} style={{padding:"5px 10px",margin:"10px",borderRadius:"20px"}}>Say</button>
            </div>
        )
    }
}
